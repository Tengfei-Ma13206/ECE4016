# PANDA
targetInterRequestTime_previous = 0.0
Video_Time_previous = 0.0
bitrate_previous = 0.0
bandwidthShare_previous = 0.0
smoothedBandwidthShare_previous = 0.0

def student_entrypoint(Measured_Bandwidth, Previous_Throughput, Buffer_Occupancy, Available_Bitrates, Video_Time, Chunk, Rebuffering_Time, Preferred_Bitrate ):
    #student can do whatever they want from here going forward
    
    R_i = list(Available_Bitrates.items())
    R_i.sort(key=lambda tup: tup[1] , reverse=True) # sort from large to small, this is for step 3
    global targetInterRequestTime_previous
    global Video_Time_previous
    global bitrate_previous
    global bandwidthShare_previous
    global smoothedBandwidthShare_previous

    if (Chunk["current"] == "0"):
        bitrate = int(R_i[-1][0]) # choose lowest bitrate for starting fluently
        bitrate_previous = bitrate
        Video_Time_previous = Video_Time
        return bitrate
    
    if (Chunk["current"] == "1"):
        # set initial value
        bandwidthShare_previous = Previous_Throughput
        smoothedBandwidthShare_previous = bandwidthShare_previous

    segmentDownloadDuration = Video_Time - Video_Time_previous
    Video_Time_previous = Video_Time # prepare for next chunk
    actual_interRequestTime_previous = max(targetInterRequestTime_previous, segmentDownloadDuration) # denoted by T[n-1] in article

    # step 1: Estimate the bandwidth share
    kappa = 0.14 # according to article, all parameter is picked as default value
    omega = 0.3
    bandwidthShare = kappa*(omega - max(0.0,bandwidthShare_previous - Previous_Throughput + omega)) * actual_interRequestTime_previous + bandwidthShare_previous
    if bandwidthShare < 0: # bandwidth share can not be negative
        bandwidthShare = 0
    bandwidthShare_previous = bandwidthShare # prepare for next chunk

    # step 2: Smooth out estimated bandwidth share by EWMA smoother
    alpha = 0.2
    smoothedBandwidthShare = (-alpha)*(smoothedBandwidthShare_previous - bandwidthShare) * actual_interRequestTime_previous + smoothedBandwidthShare_previous
    smoothedBandwidthShare_previous = smoothedBandwidthShare # prepare for next chunk

    # step 3: Quantize smoothed bandwidth share to the discrete video birate by dead-zone quantizer
    epsilon = 0.15
    delta_up = epsilon * smoothedBandwidthShare
    r_up = 0.0
    for i in range(len(R_i)): # find max available bitrate subject to the bitrate <= (smoothedBandwidthShare - delta_up)
        if int(R_i[i][0]) <= (smoothedBandwidthShare - delta_up):
            r_up = int(R_i[i][0])
            break

    delta_down = 0.0
    r_down = 0.0
    for i in range(len(R_i)): # find max available bitrate subject to the bitrate <= (smoothedBandwidthShare - delta_down)
        if int(R_i[i][0]) <= (smoothedBandwidthShare - delta_down):
            r_down = int(R_i[i][0])
            break

    if r_down == 0.0: # if we can not find the value, we pick min available bitrate
        r_down = int(R_i[len(R_i)-1][0])
    if r_up == 0.0:
        r_up = int(R_i[len(R_i)-1][0])
    # calculate bitrate by "dead zone" [r_up, r_down]
    if bitrate_previous < r_up:
        bitrate = r_up
    elif bitrate_previous <= r_down:
        bitrate  = bitrate_previous
    else:
        bitrate = r_down

    bitrate_previous = bitrate # prepare for next chunk

    # step 4 : Schedule the next download request
    B_min = 26
    beta = 0.2
    chunkTime = Chunk["time"]
    B_n_prev = Buffer_Occupancy["time"]
    targetInterRequestTime_previous = bitrate * chunkTime / smoothedBandwidthShare + beta * (B_n_prev - B_min)

    return bitrate
